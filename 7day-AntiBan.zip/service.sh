#!/system/bin/sh

#############################################
# LmzTools.sh
# Clean MLBB Cache / Record / History Files
#############################################

# Base directory for MLBB
BASE="/storage/emulated/0/Android/data/com.mobile.legends"

echo "Starting Clean Process..."

#############################################
# 1. Delete Cache Folder
#############################################
rm -rf "$BASE/cache/" 2>/dev/null

#############################################
# 2. Delete RecordVideo Folder
#############################################
rm -rf "$BASE/files/RecordVideo" 2>/dev/null

#############################################
# 3. Delete All mini_patch Folders
#############################################
find "$BASE/files/" -type d -iname "mini_patch" -exec rm -rf {} + 2>/dev/null

#############################################
# 4. Delete Record / History Related Files
#############################################
find "$BASE/files/dragon2017" 2>/dev/null | grep -iE 'record|history' | while read -r a; do
  rm -rf "$a"
done

#############################################
# 5. Delete UI Ban / Record / History / Video Files
#############################################
UI_PATH="$BASE/files/dragon2017/assets/UI/android"

if [ -d "$UI_PATH" ]; then
    find "$UI_PATH" -type f \
    \( -iname "*ban*" -o -iname "*record*" -o -iname "*history*" -o -iname "*video*" \) \
    -exec rm -f {} + 2>/dev/null
fi

echo "Clean Process Completed!"
exit 0