#!/bin/bash

BASE="/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets"

echo "Deleting MLBB asset files..."

rm -rf "$BASE/Document"
rm -f  "$BASE/Art/android/ArtResource.unity3d"
rm -rf "$BASE/AstcInPack"
rm -rf "$BASE/android"
rm -rf "$BASE/version"

echo "✅ Done! Selected files and folders deleted."